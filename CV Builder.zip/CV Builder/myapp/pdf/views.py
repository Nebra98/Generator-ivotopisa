from django import template
from django.shortcuts import render
from .models import Profile
from django.contrib import messages
from django.http import HttpResponse, response
from django.template import loader
import pdfkit
import io 
from django.utils.safestring import mark_safe

# Create your views here.
def accept(request):
    user_profile = 0

    if request.method == "POST":
        name = request.POST.get("name", "")
        dateb = request.POST.get("dateb", "")
        phone = request.POST.get("phone", "")
        email = request.POST.get("email", "")
        address = request.POST.get("address", "")
        about_you = request.POST.get("about_you", "")
        facebook = request.POST.get("facebook", "")
        instagram = request.POST.get("instagram", "")
        linkedin = request.POST.get("linkedin", "")
        github = request.POST.get("github", "")
        web = request.POST.get("web", "")
        
        start_date_1 = request.POST.get("start_date_1", "")
        end_date_1 = request.POST.get("end_date_1", "")
        e_institution_1 = request.POST.get("e_institution_1", "")
        course_1 = request.POST.get("course_1", "")
        e_grad_1 = request.POST.get("e_grad_1", "")
        e_adresa_1 = request.POST.get("e_adresa_1", "")
        e_drzava_1 = request.POST.get("e_drzava_1", "")
        start_date_2 = request.POST.get("start_date_2", "")
        end_date_2 = request.POST.get("end_date_2", "")
        e_institution_2 = request.POST.get("e_institution_2", "")
        course_2 = request.POST.get("course_2", "")
        e_grad_2 = request.POST.get("e_grad_2", "")
        e_adresa_2 = request.POST.get("e_adresa_2", "")
        e_drzava_2 = request.POST.get("e_drzava_2", "")
        start_date_3 = request.POST.get("start_date_3", "")
        end_date_3 = request.POST.get("end_date_3", "")
        e_institution_3 = request.POST.get("e_institution_3", "")
        course_3 = request.POST.get("course_3", "")
        e_grad_3 = request.POST.get("e_grad_3", "")
        e_adresa_3 = request.POST.get("e_adresa_3", "")
        e_drzava_3 = request.POST.get("e_drzava_3", "")

        
        j_start_date_1 = request.POST.get("j_start_date_1", "")
        j_end_date_1 = request.POST.get("j_end_date_1", "")
        j_institution_1 = request.POST.get("j_institution_1", "")
        j_position_1 = request.POST.get("j_position_1", "") 
        j_about_1 = request.POST.get("j_about_1", "")
        j_grad_1 = request.POST.get("j_grad_1", "") 
        j_adresa_1 = request.POST.get("j_adresa_1", "") 
        j_drzava_1 = request.POST.get("j_drzava_1", "") 
        j_start_date_2 = request.POST.get("j_start_date_2", "")
        j_end_date_2 = request.POST.get("j_end_date_2", "")
        j_institution_2 = request.POST.get("j_institution_2", "")
        j_position_2 = request.POST.get("j_position_2", "")
        j_about_2 = request.POST.get("j_about_2", "")
        j_grad_2 = request.POST.get("j_grad_2", "") 
        j_adresa_2 = request.POST.get("j_adresa_2", "") 
        j_drzava_2 = request.POST.get("j_drzava_2", "") 
        j_start_date_3 = request.POST.get("j_start_date_3", "")
        j_end_date_3 = request.POST.get("j_end_date_3", "")
        j_institution_3 = request.POST.get("j_institution_3", "")
        j_position_3 = request.POST.get("j_position_3", "")
        j_about_3 = request.POST.get("j_about_3", "")
        j_grad_3 = request.POST.get("j_grad_3", "") 
        j_adresa_3 = request.POST.get("j_adresa_3", "") 
        j_drzava_3 = request.POST.get("j_drzava_3", "") 

        
        language_1 = request.POST.get("language_1", "")
        l_knowledge_1 = request.POST.get("l_knowledge_1", "")
        language_2 = request.POST.get("language_2", "")
        l_knowledge_2 = request.POST.get("l_knowledge_2", "")
        language_3 = request.POST.get("language_3", "")
        l_knowledge_3 = request.POST.get("l_knowledge_3", "")
        skill_1 = request.POST.get("skill_1", "")
        skill_2 = request.POST.get("skill_2", "")
        skill_3 = request.POST.get("skill_3", "")
        digital_skills = request.POST.get("digital_skills", "")

        profile = Profile(name=name, dateb=dateb, phone=phone, email=email, address=address, about_you=about_you, facebook=facebook, instagram=instagram, linkedin=linkedin, github=github, web=web, start_date_1=start_date_1, end_date_1=end_date_1, e_institution_1=e_institution_1, course_1=course_1, start_date_2=start_date_2, end_date_2=end_date_2, e_institution_2=e_institution_2, course_2=course_2, start_date_3=start_date_3, end_date_3=end_date_3, e_institution_3=e_institution_3, course_3=course_3, j_start_date_1=j_start_date_1, j_end_date_1=j_end_date_1, j_institution_1=j_institution_1, j_position_1=j_position_1, j_about_1=j_about_1, j_start_date_2=j_start_date_2, j_end_date_2=j_end_date_2, j_institution_2=j_institution_2, j_position_2=j_position_2, j_about_2=j_about_2, j_start_date_3=j_start_date_3, j_end_date_3=j_end_date_3, j_institution_3=j_institution_3, j_position_3=j_position_3, j_about_3=j_about_3, language_1=language_1, l_knowledge_1=l_knowledge_1, language_2=language_2, l_knowledge_2=l_knowledge_2, language_3=language_3, l_knowledge_3=l_knowledge_3, skill_1=skill_1, skill_2=skill_2, skill_3=skill_3, digital_skills=digital_skills, e_grad_1=e_grad_1, e_adresa_1=e_adresa_1, e_drzava_1=e_drzava_1,e_grad_2=e_grad_2,e_adresa_2=e_adresa_2,e_drzava_2=e_drzava_2,e_grad_3=e_grad_3,e_adresa_3=e_adresa_3, e_drzava_3=e_drzava_3,j_grad_1=j_grad_1, j_adresa_1=j_adresa_1, j_drzava_1=j_drzava_1,j_grad_2=j_grad_2,j_adresa_2=j_adresa_2,j_drzava_2=j_drzava_2,j_grad_3=j_grad_3,j_adresa_3=j_adresa_3, j_drzava_3=j_drzava_3)
        profile.save()

        messages.info(request, mark_safe("Uspješno ste spremili životopis. <a href='/%s'>Preuzmite vaš životopis</a>" % profile.id))
        user_profile = profile.id


    return render(request, "accept.html", {'user_profile':user_profile })


def resume(request, id):
    user_profile = Profile.objects.get(pk = id) # dohvati profil korisnika gdje je primarni kljuc profila jednak prosljeđenom id-u
    template = loader.get_template("resume.html")

    digital_skills = user_profile.digital_skills
    digital_skills = digital_skills.replace(',', ' / ')

    html = template.render({'user_profile' : user_profile, 'digital_skills':digital_skills })

    option = {
        'page-size': 'Letter',
        'encoding' : 'UTF-8', 
        'enable-local-file-access': "",
        'viewport-size' : '1280x1024',
    }

    config = pdfkit.configuration(wkhtmltopdf="C:\\Program Files\\wkhtmltopdf\\bin\\wkhtmltopdf.exe")
    pdf = pdfkit.from_string(html, False, options=option, configuration=config)
    response = HttpResponse(pdf, content_type='application/pdf')
    response['Content-Disposition'] = 'attachment'
    return response

def pregled(request, id):

    digital_skills = 0

    user_profile = Profile.objects.get(pk = id)

    digital_skills = user_profile.digital_skills
    digital_skills = digital_skills.replace(',', ' / ')


    return render(request, "resume.html", {'user_profile':user_profile, 'digital_skills':digital_skills})
