from django.db import models

# Create your models here.

class Profile(models.Model):
    # osnovne informaicje
    name = models.CharField(max_length=100)
    dateb = models.CharField(max_length=100)
    phone = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    address = models.CharField(max_length=100)
    about_you = models.TextField(max_length=1000)
    facebook = models.CharField(max_length=100)
    instagram = models.CharField(max_length=100)
    linkedin = models.CharField(max_length=100)
    github = models.CharField(max_length=100)
    web = models.CharField(max_length=100)
    #obrazovanje
    start_date_1 = models.CharField(max_length=100)
    end_date_1 = models.CharField(max_length=100)
    e_institution_1 = models.CharField(max_length=100)
    course_1 = models.CharField(max_length=100)
    e_grad_1 = models.CharField(max_length=100)
    e_adresa_1 = models.CharField(max_length=100)
    e_drzava_1 = models.CharField(max_length=100)
    start_date_2 = models.CharField(max_length=100)
    end_date_2 = models.CharField(max_length=100)
    e_institution_2 = models.CharField(max_length=100)
    course_2 = models.CharField(max_length=100)
    e_grad_2 = models.CharField(max_length=100)
    e_adresa_2 = models.CharField(max_length=100)
    e_drzava_2 = models.CharField(max_length=100)
    start_date_3 = models.CharField(max_length=100)
    end_date_3 = models.CharField(max_length=100)
    e_institution_3 = models.CharField(max_length=100)
    course_3 = models.CharField(max_length=100)
    e_grad_3 = models.CharField(max_length=100)
    e_adresa_3 = models.CharField(max_length=100)
    e_drzava_3 = models.CharField(max_length=100)
    # radno iskustvo
    j_start_date_1 = models.CharField(max_length=100)
    j_end_date_1 = models.CharField(max_length=100)
    j_institution_1 = models.CharField(max_length=100)
    j_position_1 = models.CharField(max_length=100)
    j_about_1 = models.TextField(max_length=1000)
    j_grad_1 = models.CharField(max_length=100)
    j_adresa_1 = models.CharField(max_length=100)
    j_drzava_1 = models.CharField(max_length=100)
    j_start_date_2 = models.CharField(max_length=100)
    j_end_date_2 = models.CharField(max_length=100)
    j_institution_2 = models.CharField(max_length=100)
    j_position_2 = models.CharField(max_length=100)
    j_about_2 = models.TextField(max_length=1000)
    j_grad_2 = models.CharField(max_length=100)
    j_adresa_2 = models.CharField(max_length=100)
    j_drzava_2 = models.CharField(max_length=100)
    j_start_date_3 = models.CharField(max_length=100)
    j_end_date_3 = models.CharField(max_length=100)
    j_institution_3 = models.CharField(max_length=100)
    j_position_3 = models.CharField(max_length=100)
    j_about_3 = models.TextField(max_length=1000)
    j_grad_3 = models.CharField(max_length=100)
    j_adresa_3 = models.CharField(max_length=100)
    j_drzava_3 = models.CharField(max_length=100)
    # vještine
    language_1 = models.CharField(max_length=100)
    l_knowledge_1 = models.CharField(max_length=100)
    language_2 = models.CharField(max_length=100)
    l_knowledge_2 = models.CharField(max_length=100)
    language_3 = models.CharField(max_length=100)
    l_knowledge_3 = models.CharField(max_length=100)
    skill_1 = models.CharField(max_length=100)
    skill_2 = models.CharField(max_length=100)
    skill_3 = models.CharField(max_length=100)
    digital_skills = models.CharField(max_length=1000)






    


